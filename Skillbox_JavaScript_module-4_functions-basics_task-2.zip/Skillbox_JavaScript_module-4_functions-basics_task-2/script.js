
function celsiusToFahrenheit(celsius) {
    let convertToFahrenheit = celsius * 1.8 + 32;
    return Math.round(convertToFahrenheit);
}

function fahrenheitToCelsius(fahrenheit) {
    let convertToCelsius = (fahrenheit - 32) / 1.8;
    return Math.round(convertToCelsius);
}

// консоль принимает несколько значений в отличие от вызова 
// просто ф-ии кот. может принимать 1 аргумент
console.log('Цельсий в фаренгейт:', celsiusToFahrenheit(20)); 
console.log('Фаренгейт в цельсий:', fahrenheitToCelsius(70)); 
